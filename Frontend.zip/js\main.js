// js/main.js: Punto de entrada de la aplicación
import { App } from './components/App.js';

const root = document.querySelector('#root');
root.appendChild(App());