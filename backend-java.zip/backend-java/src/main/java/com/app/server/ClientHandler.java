package com.app.server;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import com.app.model.Task;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Procesa UNA petición HTTP de un cliente, leyendo y escribiendo bytes del socket a mano.
 * Se ejecuta en un hilo del ThreadPool.
 */
public class ClientHandler implements Runnable {
    private static final String TASKS_PATH = "/api/tasks";

    private final Socket clientSocket;
    private final List<Task> taskList;
    private final AtomicInteger idGenerator;
    private final Gson gson = new Gson();

    public ClientHandler(Socket socket, List<Task> taskList, AtomicInteger idGenerator) {
        this.clientSocket = socket;
        this.taskList = taskList;
        this.idGenerator = idGenerator;
    }

    @Override
    public void run() {
        try (Socket socket = clientSocket;
             InputStream in = socket.getInputStream();
             OutputStream out = socket.getOutputStream()) {

            // ---- 1. Línea de petición: "METHOD /path HTTP/1.1" ----
            String requestLine = readLine(in);
            if (requestLine == null || requestLine.isEmpty()) {
                return; // Conexión abierta por el navegador sin enviar nada
            }
            String[] parts = requestLine.split(" ");
            if (parts.length < 2) {
                sendJson(out, 400, "{\"error\":\"Peticion mal formada.\"}");
                return;
            }
            String method = parts[0].toUpperCase();
            String path = parts[1].split("\\?")[0];
            System.out.println(method + " " + path);

            // ---- 2. Headers hasta la línea en blanco ----
            int contentLength = 0;
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                int idx = line.indexOf(':');
                if (idx > 0 && line.substring(0, idx).trim().equalsIgnoreCase("Content-Length")) {
                    try {
                        contentLength = Integer.parseInt(line.substring(idx + 1).trim());
                    } catch (NumberFormatException e) {
                        contentLength = 0;
                    }
                }
            }

            // ---- 3. Body (solo si Content-Length > 0) ----
            String body = "";
            if (contentLength > 0) {
                byte[] data = in.readNBytes(contentLength);
                body = new String(data, StandardCharsets.UTF_8);
            }

            // ---- 4. Enrutamiento ----
            route(out, method, path, body);

        } catch (IOException e) {
            System.err.println("Error de I/O con el cliente: " + e.getMessage());
        }
    }

    private void route(OutputStream out, String method, String path, String body) throws IOException {
        // Preflight CORS: el navegador lo envía antes de POST/DELETE
        if (method.equals("OPTIONS")) {
            sendResponse(out, 204, "No Content", null);
            return;
        }

        if (path.equals("/") && method.equals("GET")) {
            sendJson(out, 200, "{\"mensaje\":\"API de tareas en Java con sockets\"}");
            return;
        }

        if (path.equals(TASKS_PATH)) {
            if (method.equals("GET")) {
                handleGet(out);
            } else if (method.equals("POST")) {
                handlePost(out, body);
            } else {
                sendJson(out, 405, "{\"error\":\"Metodo no permitido.\"}");
            }
            return;
        }

        if (path.startsWith(TASKS_PATH + "/") && method.equals("DELETE")) {
            handleDelete(out, path.substring(TASKS_PATH.length() + 1));
            return;
        }

        sendJson(out, 404, "{\"error\":\"Ruta no encontrada.\"}");
    }

    // GET /api/tasks
    private void handleGet(OutputStream out) throws IOException {
        String json;
        synchronized (taskList) {
            json = gson.toJson(taskList);
        }
        sendJson(out, 200, json);
    }

    // POST /api/tasks  (body: {"title":"..."})
    private void handlePost(OutputStream out, String body) throws IOException {
        String title = null;
        try {
            JsonElement parsed = JsonParser.parseString(body);
            if (parsed.isJsonObject()) {
                JsonObject obj = parsed.getAsJsonObject();
                if (obj.has("title") && obj.get("title").isJsonPrimitive()) {
                    title = obj.get("title").getAsString().trim();
                }
            }
        } catch (Exception e) {
            // JSON inválido: se trata igual que un título ausente
        }

        if (title == null || title.isEmpty()) {
            sendJson(out, 400, "{\"error\":\"El título de la tarea es requerido.\"}");
            return;
        }

        Task newTask = new Task(idGenerator.incrementAndGet(), title, false);
        taskList.add(newTask);
        sendJson(out, 201, gson.toJson(newTask));
    }

    // DELETE /api/tasks/:id
    private void handleDelete(OutputStream out, String idText) throws IOException {
        int id;
        try {
            id = Integer.parseInt(idText);
        } catch (NumberFormatException e) {
            sendJson(out, 404, "{\"error\":\"Tarea no encontrada.\"}");
            return;
        }

        boolean removed = taskList.removeIf(t -> t.getId() == id);
        if (!removed) {
            sendJson(out, 404, "{\"error\":\"Tarea no encontrada.\"}");
            return;
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Tarea eliminada exitosamente");
        result.put("id", id);
        sendJson(out, 200, gson.toJson(result));
    }

    // ---------- Utilidades de bajo nivel ----------

    /** Lee bytes hasta "\n" y devuelve la línea sin "\r\n". Null si el stream terminó. */
    private String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int b;
        while ((b = in.read()) != -1) {
            if (b == '\n') {
                break;
            }
            if (b != '\r') {
                buffer.write(b);
            }
        }
        if (b == -1 && buffer.size() == 0) {
            return null;
        }
        return buffer.toString(StandardCharsets.ISO_8859_1);
    }

    private void sendJson(OutputStream out, int status, String json) throws IOException {
        sendResponse(out, status, reason(status), json);
    }

    /** Arma la respuesta HTTP/1.1 a mano: status line + headers (con CORS) + línea en blanco + body. */
    private void sendResponse(OutputStream out, int status, String reason, String body) throws IOException {
        byte[] bodyBytes = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);

        StringBuilder head = new StringBuilder();
        head.append("HTTP/1.1 ").append(status).append(' ').append(reason).append("\r\n");
        head.append("Access-Control-Allow-Origin: *\r\n");
        head.append("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS\r\n");
        head.append("Access-Control-Allow-Headers: Content-Type\r\n");
        if (body != null) {
            head.append("Content-Type: application/json; charset=UTF-8\r\n");
        }
        head.append("Content-Length: ").append(bodyBytes.length).append("\r\n");
        head.append("Connection: close\r\n");
        head.append("\r\n");

        out.write(head.toString().getBytes(StandardCharsets.ISO_8859_1));
        out.write(bodyBytes);
        out.flush();
    }

    private String reason(int status) {
        switch (status) {
            case 200: return "OK";
            case 201: return "Created";
            case 204: return "No Content";
            case 400: return "Bad Request";
            case 404: return "Not Found";
            case 405: return "Method Not Allowed";
            default:  return "Error";
        }
    }
}