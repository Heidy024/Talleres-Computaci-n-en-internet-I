package com.app.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import com.app.model.Task;

/**
 * Servidor HTTP multihilo construido directamente sobre Sockets TCP.
 * Reemplaza a la API Express: escucha en el puerto 3001, el mismo que usa el frontend.
 */
public class TaskServer {
    private static final int PORT = 3001;
    private static final int THREAD_POOL_SIZE = 10;
    private static final int SOCKET_TIMEOUT_MS = 5000;

    // Lista en memoria, sincronizada, con las mismas tareas iniciales de la API Express
    private static final List<Task> taskList = Collections.synchronizedList(new ArrayList<>());

    // Generador de IDs: evita repetir un ID después de eliminar tareas
    private static final AtomicInteger idGenerator = new AtomicInteger(0);

    static {
        taskList.add(new Task(idGenerator.incrementAndGet(), "Comprender la estructura básica de HTML y CSS", true));
        taskList.add(new Task(idGenerator.incrementAndGet(), "Aprender a seleccionar y modificar elementos del DOM", true));
        taskList.add(new Task(idGenerator.incrementAndGet(), "Entender qué es una Promesa y sus tres estados en JS", false));
        taskList.add(new Task(idGenerator.incrementAndGet(), "Consumir una API externa usando fetch y async/await", false));
        taskList.add(new Task(idGenerator.incrementAndGet(), "Renderizar dinámicamente los datos en la interfaz web", false));
    }

    public static void main(String[] args) {
        ExecutorService threadPool = Executors.newFixedThreadPool(THREAD_POOL_SIZE);

        System.out.println("Iniciando servidor HTTP sobre sockets en http://localhost:" + PORT);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept(); // Bloqueante
                // Evita que conexiones inactivas del navegador ocupen hilos del pool para siempre
                clientSocket.setSoTimeout(SOCKET_TIMEOUT_MS);
                threadPool.execute(new ClientHandler(clientSocket, taskList, idGenerator));
            }
        } catch (IOException e) {
            System.err.println("Error crítico en el servidor TCP: " + e.getMessage());
        } finally {
            threadPool.shutdown();
        }
    }
}